import 'dart:convert';

import 'package:get/get.dart';
import 'package:dartz/dartz.dart';
import 'package:mobile_erp/API/URLConst.dart';
import 'package:mobile_erp/features/Quotation/controller/quotation_controller.dart';
import 'package:mobile_erp/features/Quotation/data/model/get_prescription_model.dart';
import 'package:mobile_erp/features/orders/controller/OrderListController.dart';
import 'package:mobile_erp/features/orders/data/datasource/orderplaced_datasource_repository.dart';
import 'package:mobile_erp/features/orders/data/model/getOrderDetails.dart';
import 'package:mobile_erp/features/orders/data/model/getOrderPlacedModel.dart';
import 'package:http/http.dart' as http;

import '../../../../core/error/failure.dart';


class OrderPlacedDataSourceImpl implements OrderPlacedSourceRepository {
  OrderPlacedDataSourceImpl();

  @override
  Future<Either<Failure, List<GetOrderPlacedModel>>>
      getOrderPlacedData() async {
    try {
      print('Order Placed Data called');
      var response = await http.get(Uri.parse(URLConst.OrderPlacedURL),);
      print(response.runtimeType);
       print(jsonDecode(response.body));

      if (response.statusCode == 200) {
         List<dynamic> data = jsonDecode(response.body);
        // var data1 = jsonDecode(response.body);
        // var data = data1['orders'];

        print(data);
        List<GetOrderPlacedModel> order = [];
        data.forEach((element) {
          order.add(GetOrderPlacedModel.fromJson(element));
        });

        print('orderplaced is : $order');
        return Right(order);
      } else {
        return Left(Failure(statusCode: 500, message: 'Failed!'));
      }
    } catch (err) {
      print(err);
      return Left(Failure(statusCode: 500, message: 'Error occurred!'));
    }
  }

  @override
  Future<Either<Failure, Map<String, dynamic>>> getOrderDetails(String currentcardid) async {
    try {
      print('Order Details Data called');
      var response = await http.post(
        Uri.parse(URLConst.OrderDetailsURL + currentcardid),
      );
      
      print(response.runtimeType);
      // print(jsonDecode(response.body));
      print("******************");
      print(response.statusCode);
      print(response.body);
      print("******************");

      if (response.statusCode == 200) {
        // List<dynamic> data = jsonDecode(response.body);
        var data1 = jsonDecode(response.body);
        var data = data1['data']['order'];
        var data2 = data1['data']['prescription'];
        var data3 = data1['sales_order_pdf_url'];

        print(data);
        print(data2);
        String jsonString = jsonEncode(data2); // Assuming data2 is the JSON Map
        GetCustomerPrescriptionModel pres =
            GetCustomerPrescriptionModel.fromJson(jsonString);
        OrderDetailsModel order = OrderDetailsModel.fromJson(data);

        Map<String, dynamic> map = {
          "order_detail": order,
          "prescription_detail": pres,
          "sales_order_pdf_url": data3
        };
        print('orderplaced is : $order');
        return Right(map);
      } else {
        return Left(Failure(statusCode: 500, message: 'Failed!'));
      }
    } catch (err) {
      print(err);
      return Left(Failure(statusCode: 500, message: 'Error occurred!'));
    }
  }
}
