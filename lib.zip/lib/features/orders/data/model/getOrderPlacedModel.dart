class GetOrderPlacedModel {
  int? id;
  int? userId;
  int? customerId;
  int? prescriptionId;
  String? totalAmount;
  String? amount;
  String? totalGst;
  String? advanceAmount;
  String? discount;
  String? paymentType;
  String? paymentSettlement;
  String? paidAmount;
  int? orderStatus;
  int? storeId;
  String? strOrderSeries;
  String? createdAt;
  String? updatedAt;
  int? status;
  String? paymentMethods;
  List<Orderpayments>? orderpayments;

  GetOrderPlacedModel(
      {this.id,
        this.userId,
        this.customerId,
        this.prescriptionId,
        this.totalAmount,
        this.amount,
        this.totalGst,
        this.advanceAmount,
        this.discount,
        this.paymentType,
        this.paymentSettlement,
        this.paidAmount,
        this.orderStatus,
        this.storeId,
        this.strOrderSeries,
        this.createdAt,
        this.updatedAt,
        this.status,
        this.paymentMethods,
        this.orderpayments});

  GetOrderPlacedModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    customerId = json['customer_id'];
    prescriptionId = json['prescription_id'];
    totalAmount = json['total_amount'];
    amount = json['amount'];
    totalGst = json['total_gst'];
    advanceAmount = json['advance_amount'];
    discount = json['discount'];
    paymentType = json['payment_type'];
    paymentSettlement = json['payment_settlement'];
    paidAmount = json['paid_amount'];
    orderStatus = json['order_status'];
    storeId = json['store_id'];
    strOrderSeries = json['str_order_series'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    status = json['status'];
    paymentMethods = json['payment_methods'];
    if (json['orderpayments'] != null) {
      orderpayments = <Orderpayments>[];
      json['orderpayments'].forEach((v) {
        orderpayments!.add(new Orderpayments.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['customer_id'] = this.customerId;
    data['prescription_id'] = this.prescriptionId;
    data['total_amount'] = this.totalAmount;
    data['amount'] = this.amount;
    data['total_gst'] = this.totalGst;
    data['advance_amount'] = this.advanceAmount;
    data['discount'] = this.discount;
    data['payment_type'] = this.paymentType;
    data['payment_settlement'] = this.paymentSettlement;
    data['paid_amount'] = this.paidAmount;
    data['order_status'] = this.orderStatus;
    data['store_id'] = this.storeId;
    data['str_order_series'] = this.strOrderSeries;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['status'] = this.status;
    data['payment_methods'] = this.paymentMethods;
    if (this.orderpayments != null) {
      data['orderpayments'] =
          this.orderpayments!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Orderpayments {
  int? id;
  int? orderId;
  String? paymentType;
  num? paidAmount;
  String? createdAt;
  String? updatedAt;
  int? status;
  Null? paymentTime;

  Orderpayments(
      {this.id,
        this.orderId,
        this.paymentType,
        this.paidAmount,
        this.createdAt,
        this.updatedAt,
        this.status,
        this.paymentTime});

  Orderpayments.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    orderId = json['order_id'];
    paymentType = json['payment_type'];
    paidAmount =  json['paid_amount'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    status = json['status'];
    paymentTime = json['payment_time'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['order_id'] = this.orderId;
    data['payment_type'] = this.paymentType;
    data['paid_amount'] = this.paidAmount;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['status'] = this.status;
    data['payment_time'] = this.paymentTime;
    return data;
  }
}
