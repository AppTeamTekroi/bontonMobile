import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:mobile_erp/core/enum/post_enum_response.dart';
import 'package:mobile_erp/features/Quotation/presentation/pages/quotation.dart';
import 'package:mobile_erp/features/customer/controller/customer_controller.dart';
import 'package:mobile_erp/features/customer/data/model/get_customer_model.dart';
import 'package:mobile_erp/features/product/controller/product_controller.dart';
import 'package:mobile_erp/features/product/data/model/get_product_data_model.dart';
import 'package:mobile_erp/features/product/presentation/pages/add_product.dart';
import 'package:mobile_erp/features/product/presentation/pages/barcode_searched_product.dart';
import 'package:mobile_erp/features/product/presentation/pages/cartScreen.dart';
import 'package:mobile_erp/features/product/presentation/widget/productCard.dart';
import 'package:mobile_erp/ui/color/appColor.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shimmer/shimmer.dart';

import '../../../../constants/sized_box_utils.dart';
import '../../../../ui/Buttons/buttonBS.dart';
import '../../../../ui/amountComma.dart';
import '../../../../ui/options_button.dart';
import '../../../Quotation/presentation/pages/pdfview.dart';

class SelectProductScreen extends StatefulWidget {
  CustomersModel? customer;
  SelectProductScreen({super.key, this.customer});

  @override
  State<SelectProductScreen> createState() => _SelectProductScreenState();
}

class _SelectProductScreenState extends State<SelectProductScreen> {
  ProductController pc = Get.find();
  CustomerController cc = Get.find();
  final RxList<int> selectedBrands = <int>[].obs;
  final RxList<int> selectedmodals = <int>[].obs;
  List<int> selectedIndices = [];

  var selectedBrandName = [];
  var selectedModelName = [];
  List<String> selectedIndicesType = [];
  var selectedCategories = <String>[].obs; // RxList<String>

  var selectedCategorylName = <String>[].obs; // RxList<String>

  @override
  void initState() {
    pc.getCartItemDetailsList(cc.selectedCustomer.value?.cardCode.toString());
    pc.brandsList(context);
    pc.modelList(context);
    // pc.calculateamount();
    // TODO: implement initState
    super.initState();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    // pc.count.value = 0.0;
    // pc.clearDetails();

    pc.searchProductByName('');
    cc.initializeVariables(billing: true, shipping: true);
    // pc.getProductDetailsList();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      pc.setCartProductInitally();
    });
    super.dispose();
  }

  Future<void> fetchType() async {
    pc.searchType = selectedIndicesType;
    await pc.getProductDetailsList();

  }


  // void _showBrandsMenu(BuildContext context) {
  //   final TextEditingController brandController = TextEditingController();
  //   final TextEditingController modelController = TextEditingController();
  //   final TextEditingController categoryController = TextEditingController();
  //
  //   // Separate search queries for each filter
  //   final RxString brandSearch = "".obs;
  //   final RxString modelSearch = "".obs;
  //   final RxString categorySearch = "".obs;
  //
  //   final RxString selectedFilter = "Categories".obs;
  //
  //   // Category static data
  //   final List<Map<String, String>> categories = [
  //     {"label": "Sunglasses", "key": "Sunglasses"},
  //     {"label": "Contact Lens", "key": "contact_lens"},
  //     {"label": "Ophthalmic Lenses", "key": "OPhthalmic Lenses"},
  //     {"label": "Accessories", "key": "Accessories"},
  //   ];
  //
  //   showModalBottomSheet(
  //     context: context,
  //     isScrollControlled: true,
  //     backgroundColor: Colors.transparent,
  //     builder: (_) {
  //       return DraggableScrollableSheet(
  //         expand: false,
  //         initialChildSize: 0.8,
  //         minChildSize: 0.4,
  //         maxChildSize: 0.95,
  //         builder: (context, scrollController) {
  //           return Container(
  //             decoration: const BoxDecoration(
  //               color: Colors.white,
  //               borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
  //             ),
  //             child: Column(
  //               children: [
  //                 // HEADER
  //                 Container(
  //                   padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
  //                   decoration: BoxDecoration(
  //                     border: Border(
  //                       bottom: BorderSide(color: Colors.grey.shade300),
  //                     ),
  //                   ),
  //                   child: Row(
  //                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //                     children: [
  //                       const Text(
  //                         "Filters",
  //                         style: TextStyle(
  //                           fontSize: 18,
  //                           fontWeight: FontWeight.bold,
  //                         ),
  //                       ),
  //                       TextButton(
  //                         onPressed: () async {
  //                           // Clear all selections
  //                           selectedBrands.clear();
  //                           selectedBrandName.clear();
  //                           selectedmodals.clear();
  //                           selectedModelName.clear();
  //                           selectedCategories.clear();
  //
  //                           // Reset controller search filters
  //                           pc.searchBrand = [];
  //                           pc.searchModel = [];
  //                           pc.searchType = [];
  //
  //                           Navigator.pop(context);
  //
  //                           // Reload product list
  //                           await pc.getProductDetailsList();
  //                         },
  //                         child: const Text(
  //                           "Clear Filters",
  //                           style: TextStyle(
  //                             color: Colors.red,
  //                             fontWeight: FontWeight.bold,
  //                           ),
  //                         ),
  //                       ),
  //                     ],
  //                   ),
  //                 ),
  //
  //                 Expanded(
  //                   child: Row(
  //                     children: [
  //                       // LEFT MENU
  //                       Container(
  //                         width: 125,
  //                         color: Colors.grey[100],
  //                         child: Column(
  //                           children: [
  //                             Obx(() => ListTile(
  //                               title: const Text("Categories"),
  //                               selected: selectedFilter.value == "Categories",
  //                               selectedTileColor: Colors.blue.shade50,
  //                               textColor: selectedFilter.value == "Categories"
  //                                   ? Colors.blue
  //                                   : Colors.black,
  //                               onTap: () => selectedFilter.value = "Categories",
  //                             )),
  //                             Obx(() => ListTile(
  //                               title: const Text("Brands"),
  //                               selected: selectedFilter.value == "Brands",
  //                               selectedTileColor: Colors.blue.shade50,
  //                               textColor: selectedFilter.value == "Brands"
  //                                   ? Colors.blue
  //                                   : Colors.black,
  //                               onTap: () => selectedFilter.value = "Brands",
  //                             )),
  //                             Obx(() => ListTile(
  //                               title: const Text("Models"),
  //                               selected: selectedFilter.value == "Models",
  //                               selectedTileColor: Colors.blue.shade50,
  //                               textColor: selectedFilter.value == "Models"
  //                                   ? Colors.blue
  //                                   : Colors.black,
  //                               onTap: () => selectedFilter.value = "Models",
  //                             )),
  //
  //                           ],
  //                         ),
  //                       ),
  //
  //                       // RIGHT CONTENT
  //                       Expanded(
  //                         child: Obx(() {
  //                           // Determine current search query based on selected filter
  //                           TextEditingController currentController;
  //                           RxString currentSearch;
  //
  //                           switch (selectedFilter.value) {
  //                             case "Categories":
  //                               currentController = categoryController;
  //                               currentSearch = categorySearch;
  //                               break;
  //                             case "Brands":
  //                               currentController = brandController;
  //                               currentSearch = brandSearch;
  //                               break;
  //                             case "Models":
  //                               currentController = modelController;
  //                               currentSearch = modelSearch;
  //                               break;
  //
  //                               break;
  //                             default:
  //                               currentController = brandController;
  //                               currentSearch = brandSearch;
  //                           }
  //
  //                           // CATEGORIES
  //                           if (selectedFilter.value == "Categories") {
  //                             final filteredCategories = categories.where((cat) {
  //                               final label = cat["label"]!.toLowerCase();
  //                               return label.contains(categorySearch.value.toLowerCase());
  //                             }).toList();
  //
  //                             return Column(
  //                               children: [
  //                                 // Search bar
  //                                 Padding(
  //                                   padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
  //                                   child: Container(
  //                                     height: 42,
  //                                     decoration: BoxDecoration(
  //                                       color: Colors.white,
  //                                       borderRadius: BorderRadius.circular(24),
  //                                       boxShadow: [
  //                                         BoxShadow(
  //                                           color: Colors.black12,
  //                                           blurRadius: 4,
  //                                           offset: Offset(0, 2),
  //                                         ),
  //                                       ],
  //                                     ),
  //                                     child: TextField(
  //                                       controller: currentController,
  //                                       onChanged: (value) => currentSearch.value = value,
  //                                       decoration: InputDecoration(
  //                                         contentPadding: const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
  //                                         hintText: "Search ${selectedFilter.value}",
  //                                         hintStyle: TextStyle(color: Colors.grey[600], fontSize: 14),
  //                                         prefixIcon: Icon(Icons.search, color: Colors.grey[600], size: 22),
  //                                         border: InputBorder.none,
  //                                       ),
  //                                     ),
  //                                   ),
  //                                 ),                                  Expanded(
  //                                   child: ListView.builder(
  //                                     controller: scrollController,
  //                                     itemCount: filteredCategories.length,
  //                                     itemBuilder: (context, index) {
  //                                       final cat = filteredCategories[index];
  //                                       return Obx(() {
  //                                         final isSelected = selectedCategories.contains(cat["key"]!);
  //                                         return InkWell(
  //                                           onTap: () {
  //                                             if (isSelected) {
  //                                               selectedCategories.remove(cat["key"]!);
  //                                             } else {
  //                                               selectedCategories.add(cat["key"]!);
  //                                             }
  //                                           },
  //                                           child: Container(
  //                                             padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
  //                                             color: isSelected ? Colors.blue.shade50 : Colors.white,
  //                                             child: Row(
  //                                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //                                               children: [
  //                                                 Text(
  //                                                   cat["label"]!,
  //                                                   style: TextStyle(
  //                                                     fontSize: 14,
  //                                                     fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
  //                                                     color: isSelected ? Colors.blue : Colors.black,
  //                                                   ),
  //                                                 ),
  //                                                 if (isSelected) const Icon(Icons.check, color: Colors.blue),
  //                                               ],
  //                                             ),
  //                                           ),
  //                                         );
  //                                       });
  //                                     },
  //                                   ),
  //                                 ),
  //                               ],
  //                             );
  //                           }
  //
  //                           // BRANDS & MODELS
  //                           if ((selectedFilter.value == "Brands" && pc.isLoading8.value) ||
  //                               (selectedFilter.value == "Models" && pc.isLoading9.value)) {
  //                             return const Center(child: CircularProgressIndicator());
  //                           }
  //
  //                           if ((selectedFilter.value == "Brands" && pc.errorMessage8.isNotEmpty) ||
  //                               (selectedFilter.value == "Models" && pc.errorMessage9.isNotEmpty)) {
  //                             return Center(
  //                               child: Text(selectedFilter.value == "Brands"
  //                                   ? pc.errorMessage8.value
  //                                   : pc.errorMessage9.value),
  //                             );
  //                           }
  //
  //                           final dataList = selectedFilter.value == "Brands" ? pc.brandData : pc.modelData;
  //                           final selectedList = selectedFilter.value == "Brands" ? selectedBrands : selectedmodals;
  //                           final nameList = selectedFilter.value == "Brands" ? selectedBrandName : selectedModelName;
  //                           final keyName = selectedFilter.value == "Brands" ? 'name' : 'model_name';
  //
  //                           final filteredList = dataList.where((item) {
  //                             final itemName = (item[keyName] ?? "").toString().toLowerCase();
  //                             return itemName.contains(currentSearch.value.toLowerCase());
  //                           }).toList();
  //
  //                           return Column(
  //                             children: [
  //                               // Search bar
  //                               Padding(
  //                                 padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
  //                                 child: Container(
  //                                   height: 42,
  //                                   decoration: BoxDecoration(
  //                                     color: Colors.white,
  //                                     borderRadius: BorderRadius.circular(24),
  //                                     boxShadow: [
  //                                       BoxShadow(
  //                                         color: Colors.black12,
  //                                         blurRadius: 4,
  //                                         offset: Offset(0, 2),
  //                                       ),
  //                                     ],
  //                                   ),
  //                                   child: TextField(
  //                                     controller: currentController,
  //                                     onChanged: (value) => currentSearch.value = value,
  //                                     decoration: InputDecoration(
  //                                       contentPadding: const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
  //                                       hintText: "Search ${selectedFilter.value}",
  //                                       hintStyle: TextStyle(color: Colors.grey[600], fontSize: 14),
  //                                       prefixIcon: Icon(Icons.search, color: Colors.grey[600], size: 22),
  //                                       border: InputBorder.none,
  //                                     ),
  //                                   ),
  //                                 ),
  //                               ),
  //                               Expanded(
  //                                 child: ListView.builder(
  //                                   controller: scrollController,
  //                                   itemCount: filteredList.length,
  //                                   itemBuilder: (context, index) {
  //                                     var item = filteredList[index];
  //                                     int itemId = item['id'];
  //                                     String itemName = item[keyName];
  //
  //                                     return Obx(() {
  //                                       final isSelected = selectedList.contains(itemId);
  //                                       return InkWell(
  //                                         onTap: () {
  //                                           if (isSelected) {
  //                                             selectedList.remove(itemId);
  //                                             nameList.remove(itemName);
  //                                           } else {
  //                                             selectedList.add(itemId);
  //                                             nameList.add(itemName);
  //                                           }
  //                                         },
  //                                         child: Container(
  //                                           padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
  //                                           color: isSelected ? Colors.blue.shade50 : Colors.transparent,
  //                                           child: Row(
  //                                             mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //                                             children: [
  //                                               Text(
  //                                                 itemName,
  //                                                 style: TextStyle(
  //                                                   fontSize: 12,
  //                                                   fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
  //                                                   color: isSelected ? Colors.blue : Colors.black,
  //                                                 ),
  //                                               ),
  //                                               if (isSelected) const Icon(Icons.check, color: Colors.blue),
  //                                             ],
  //                                           ),
  //                                         ),
  //                                       );
  //                                     });
  //                                   },
  //                                 ),
  //                               )
  //                             ],
  //                           );
  //                         }),
  //                       ),
  //                     ],
  //                   ),
  //                 ),
  //
  //                 // APPLY BUTTON
  //                 ButtonBS(
  //                   title: 'Apply Filters',
  //                   padding: 10,
  //                   height: 50,
  //                   backgroundColor: AppColors.mainblue,
  //                   textColor: Colors.white,
  //                   onPressed: () async {
  //                     Navigator.pop(context);
  //                     pc.searchBrand = selectedBrandName;
  //                     pc.searchModel = selectedModelName;
  //                     pc.searchType = selectedCategories;
  //                     await pc.getProductDetailsList();
  //                   },
  //                 ),
  //               ],
  //             ),
  //           );
  //         },
  //       );
  //     },
  //   );
  // }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primary,
      appBar: AppBar(
        scrolledUnderElevation: 0,
        toolbarHeight: 70,
        leadingWidth: 40,
        backgroundColor: AppColors.white,
        leading: Padding(
          padding: EdgeInsets.only(left: 12),
          child: GestureDetector(
            onTap: () {
              Navigator.of(context).pop();
            },
            child: Icon(
              Icons.arrow_back_ios_sharp,
              size: 20,
            ),
          ),
        ),
        title:

        Row(
          children: [
            // Padding(
            //   padding: const EdgeInsets.only(right: 8.0),
            //   child: GestureDetector(
            //     onTap: () {
            //       // Navigator.push(
            //       //   context,
            //       //   MaterialPageRoute(
            //       //     builder: ((context) => AddProduct()),
            //       //   ),
            //       // );
            //     },
            //     child: Container(
            //       color: Colors.white,
            //       height: 60,
            //       child: Row(
            //         children: [
            //           // GestureDetector(
            //           //   onTap:   () {
            //           //     _showBrandsMenu(context);
            //           //   },
            //           //
            //           //   child: Image.asset("lib/ui/assets/setting.png",height: 25,),),
            //
            //           //                         Expanded(
            //           //                           child: SingleChildScrollView(
            //           //                             scrollDirection: Axis.horizontal,
            //           //                             physics: const AlwaysScrollableScrollPhysics(),
            //           //                             child: Padding(
            //           //                                 padding: const EdgeInsets.only(bottom: 5.0,left: 8,right: 8),
            //           //                                 child:Row(
            //           //                                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //           //                                   children: [
            //           //                                     OptionButtons(
            //           //                                       label: 'Ophthalmic Lenses',
            //           //                                       isSelected: selectedIndices.contains(0),
            //           //                                       onTap: () {
            //           //                                         setState(() {
            //           //                                           if (selectedIndices.contains(0)) {
            //           //                                             selectedIndices.remove(0);
            //           //                                             selectedIndicesType.remove('OPhthalmic Lenses');
            //           // // unselect
            //           //                                           } else {
            //           //                                             selectedIndices.add(0);
            //           //                                             selectedIndicesType.add('OPhthalmic Lenses');
            //           // // select
            //           //                                           }
            //           //                                         });
            //           //                                         fetchType();
            //           //                                       },
            //           //                                     ),
            //           //                                     SizedBoxUtils.width3,
            //           //                                     OptionButtons(
            //           //                                       label: 'Sun Glasses',
            //           //                                       isSelected: selectedIndices.contains(1),
            //           //                                       onTap: () {
            //           //                                         setState(() {
            //           //                                           if (selectedIndices.contains(1)) {
            //           //                                             selectedIndices.remove(1);
            //           //                                             selectedIndicesType.remove('Sunglasses');
            //           //
            //           //                                           } else {
            //           //                                             selectedIndices.add(1);
            //           //                                             selectedIndices.remove(2);
            //           //                                             selectedIndicesType.add('Sunglasses');
            //           //
            //           //                                           }
            //           //                                         });
            //           //                                         fetchType();
            //           //
            //           //                                       },
            //           //                                     ),
            //           //                                     SizedBoxUtils.width3,
            //           //                                     OptionButtons(
            //           //                                       label: 'Contact Lens',
            //           //                                       isSelected: selectedIndices.contains(2),
            //           //                                       onTap: () {
            //           //                                         setState(() {
            //           //                                           if (selectedIndices.contains(2)) {
            //           //                                             selectedIndices.remove(2);
            //           //                                             selectedIndicesType.remove('contact_lens');
            //           //
            //           //                                           } else {
            //           //                                             selectedIndices.add(2);
            //           //                                             selectedIndices.remove(2);
            //           //                                             selectedIndicesType.add('contact_lens');
            //           //
            //           //                                           }
            //           //                                         });
            //           //                                         fetchType();
            //           //
            //           //                                       },
            //           //                                     ),
            //           //                                     SizedBoxUtils.width3,
            //           //                                     OptionButtons(
            //           //                                       label: 'Accessories',
            //           //                                       isSelected: selectedIndices.contains(3),
            //           //                                       onTap: () {
            //           //                                         setState(() {
            //           //                                           if (selectedIndices.contains(3)) {
            //           //                                             selectedIndices.remove(3);
            //           //                                             selectedIndicesType.remove("Accessoreis");
            //           //                                           } else {
            //           //                                             selectedIndices.add(3);
            //           //                                             selectedIndicesType.add("Accessoreis");
            //           //
            //           //                                           }
            //           //                                         });
            //           //                                         fetchType();
            //           //
            //           //                                       },
            //           //                                     ),
            //           //                                   ],
            //           //                                 )
            //           //
            //           //                             ),
            //           //                           ),
            //           //                         ),
            //         ],
            //       ),
            //     ),
            //   ),
            // ),
            Expanded(
              child: Container(
                margin: EdgeInsets.only(right: 0, left: 0),
                decoration: BoxDecoration(
                    color: AppColors.primary,
                    borderRadius: BorderRadius.circular(10)),
                child: Padding(
                  padding: const EdgeInsets.only(left: 10, right: 5),
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: "Search Products",
                      suffixIcon: Obx(
                            () => pc.searchProduct.isNotEmpty
                            ? Padding(
                          padding: const EdgeInsets.only(top: 15),
                          child: Padding(
                            padding: const EdgeInsets.only(left: 8, right: 8),
                            child: Text(
                              'Search',
                              style: TextStyle(fontSize: 15),
                            ),
                          ),
                        )
                            : Icon(
                          Icons.search,
                          color: Colors.grey,
                        ),
                      ),
                      hintStyle: TextStyle(fontSize: 18, fontWeight: FontWeight.w400),
                      border: InputBorder.none,
                    ),
                    onChanged: (val) {
                      pc.searchProduct.value = val;
                      pc.searchProductByName(pc.searchProduct.value);
                    },
                  ),
                ),
              ),
            ),
          ],
        ),
        actions: [
          // Padding(
          //   padding: const EdgeInsets.only(right: 15.0),
          //   child: GestureDetector(
          //     onTap:   () {
          //       _showBrandsMenu(context);
          //     },
          //
          //     child: const Icon(Icons.filter_alt_rounded
          //   ),
          // ),
          // ),

          Padding(
            padding: const EdgeInsets.only(right: 15),
            child: GestureDetector(
              // onTap: () async {
              //   var res = await Navigator.push(
              //       context,
              //       MaterialPageRoute(
              //         builder: (context) => const SimpleBarcodeScannerPage(),
              //       ));
              //   if (res != null && res is String) {
              //     print('response from barcode: ${res}');
              //     //  PostResponseType res = await pc.postAddToCart(
              //     //                   widget.product.id.toString(),
              //     //                   cc.selectedCustomer.value?.id.toString() ??
              //     //                       '',
              //     //                   selectedQty.value.toString());
              //     //               // print(res.postResponseEnum);
              //     //               if (res.postResponseEnum ==
              //     //                   PostResponseEnum.success) {
              //     //                 Get.showSnackbar(GetSnackBar(
              //     //                   title: 'Success',
              //     //                   message: 'Product Added to Cart',
              //     //                   snackPosition: SnackPosition.BOTTOM,
              //     //                   backgroundColor: AppColors.mainblue,
              //     //                   duration:
              //     //                       const Duration(milliseconds: 1000),
              //     //                 ));
              //     //               }
              //     await pc.getProductFromBarcode(res);
              //     if (pc.getBarcodeSearchDetailList.isNotEmpty) {
              //       PostResponseType res = await pc.postAddToCart(
              //           pc.getBarcodeSearchDetailList[0].id.toString(),
              //           cc.selectedCustomer.value?.id.toString() ?? '',
              //           '1');
              //       // print(res.postResponseEnum);
              //       if (res.postResponseEnum == PostResponseEnum.success) {
              //         Get.showSnackbar(GetSnackBar(
              //           title: 'Success',
              //           message: 'Product Added to Cart',
              //           snackPosition: SnackPosition.BOTTOM,
              //           backgroundColor: AppColors.mainblue,
              //           duration: const Duration(milliseconds: 1000),
              //         ));
              //       }
              //       print('we got a product with same barcode');
              //     } else {
              //       print('we cant find anything');
              //     }
              //   }
              //   // print('response from barcode: ${res}');
              // },
              child: FaIcon(
                FontAwesomeIcons.barcode,
                color: Colors.black,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 10),
            child: GestureDetector(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => CartScreen(
                            customerId: widget.customer?.cardCode.toString()
                        ),
                      ));
                },
                child: Icon(
                  Icons.shopping_cart_outlined,
                  color: Colors.black,
                )),
          )
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _filterButton("Category", _showCategorySheet),
                _filterButton("Brand", _showBrandSheet),
                _filterButton("Model", _showModelSheet),
              ],
            ),
          ),


//           Row(
//             children: [
//
//               Expanded(
//                 child:
//         //         Obx(
//         //               () =>
//         // // pc.getProductDetailList.isEmpty
//         //           //     ? Shimmer.fromColors(
//         //           //   baseColor: Colors.grey.shade300,
//         //           //   highlightColor: Colors.grey.shade100,
//         //           //   child: Container(
//         //           //     height: 40,
//         //           //     width: double.maxFinite,
//         //           //     decoration: BoxDecoration(
//         //           //       color: Colors.grey.shade300,
//         //           //       borderRadius: BorderRadius.only(
//         //           //         bottomLeft: Radius.circular(15),
//         //           //         bottomRight: Radius.circular(15),
//         //           //       ),
//         //           //     ),
//         //           //   ),
//         //           // )
//         //           //     :
//         //
//         //         ),
//                 GestureDetector(
//                   onTap: () {
//                     // Navigator.push(
//                     //   context,
//                     //   MaterialPageRoute(
//                     //     builder: ((context) => AddProduct()),
//                     //   ),
//                     // );
//                   },
//                   child: Container(
//                     color: Colors.white,
//                     height: 60,
//                     child: Row(
//                       children: [
//                         GestureDetector(
//                           onTap:   () {
//                             _showBrandsMenu(context);
//                           },
//
//                           child: Image.asset("lib/ui/assets/setting.png",height: 30,),),
//
// //                         Expanded(
// //                           child: SingleChildScrollView(
// //                             scrollDirection: Axis.horizontal,
// //                             physics: const AlwaysScrollableScrollPhysics(),
// //                             child: Padding(
// //                                 padding: const EdgeInsets.only(bottom: 5.0,left: 8,right: 8),
// //                                 child:Row(
// //                                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
// //                                   children: [
// //                                     OptionButtons(
// //                                       label: 'Ophthalmic Lenses',
// //                                       isSelected: selectedIndices.contains(0),
// //                                       onTap: () {
// //                                         setState(() {
// //                                           if (selectedIndices.contains(0)) {
// //                                             selectedIndices.remove(0);
// //                                             selectedIndicesType.remove('OPhthalmic Lenses');
// // // unselect
// //                                           } else {
// //                                             selectedIndices.add(0);
// //                                             selectedIndicesType.add('OPhthalmic Lenses');
// // // select
// //                                           }
// //                                         });
// //                                         fetchType();
// //                                       },
// //                                     ),
// //                                     SizedBoxUtils.width3,
// //                                     OptionButtons(
// //                                       label: 'Sun Glasses',
// //                                       isSelected: selectedIndices.contains(1),
// //                                       onTap: () {
// //                                         setState(() {
// //                                           if (selectedIndices.contains(1)) {
// //                                             selectedIndices.remove(1);
// //                                             selectedIndicesType.remove('Sunglasses');
// //
// //                                           } else {
// //                                             selectedIndices.add(1);
// //                                             selectedIndices.remove(2);
// //                                             selectedIndicesType.add('Sunglasses');
// //
// //                                           }
// //                                         });
// //                                         fetchType();
// //
// //                                       },
// //                                     ),
// //                                     SizedBoxUtils.width3,
// //                                     OptionButtons(
// //                                       label: 'Contact Lens',
// //                                       isSelected: selectedIndices.contains(2),
// //                                       onTap: () {
// //                                         setState(() {
// //                                           if (selectedIndices.contains(2)) {
// //                                             selectedIndices.remove(2);
// //                                             selectedIndicesType.remove('contact_lens');
// //
// //                                           } else {
// //                                             selectedIndices.add(2);
// //                                             selectedIndices.remove(2);
// //                                             selectedIndicesType.add('contact_lens');
// //
// //                                           }
// //                                         });
// //                                         fetchType();
// //
// //                                       },
// //                                     ),
// //                                     SizedBoxUtils.width3,
// //                                     OptionButtons(
// //                                       label: 'Accessories',
// //                                       isSelected: selectedIndices.contains(3),
// //                                       onTap: () {
// //                                         setState(() {
// //                                           if (selectedIndices.contains(3)) {
// //                                             selectedIndices.remove(3);
// //                                             selectedIndicesType.remove("Accessoreis");
// //                                           } else {
// //                                             selectedIndices.add(3);
// //                                             selectedIndicesType.add("Accessoreis");
// //
// //                                           }
// //                                         });
// //                                         fetchType();
// //
// //                                       },
// //                                     ),
// //                                   ],
// //                                 )
// //
// //                             ),
// //                           ),
// //                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//              ),
//             ],
//           ),
//           Padding(
//               padding: const EdgeInsets.only(left: 8.0),
//               child: Column(
//                 mainAxisSize: MainAxisSize.min, // shrink column height
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//
//                   // --- Brands Chips ---
//                   Obx(() {
//                     if (selectedBrands.isEmpty) return SizedBox.shrink();
//                     return SingleChildScrollView(
//                       scrollDirection: Axis.horizontal,
//                       child: Row(
//                         children: selectedBrands.map((id) {
//                           final brand = pc.brandData
//                               .firstWhere((b) => b['id'] == id, orElse: () => {});
//                           return Padding(
//                             padding: const EdgeInsets.only(right: 4.0), // smaller horizontal spacing
//                             child: Chip(
//                               backgroundColor: Colors.white,
//                               visualDensity: VisualDensity.compact, // reduces height
//                               padding: EdgeInsets.zero, // remove internal padding
//                               labelPadding: EdgeInsets.symmetric(horizontal: 4.0, vertical: 2.0),
//                               label: Text(
//                                 brand['name'] ?? "",
//                                 style: TextStyle(fontSize: 10), // smaller text
//                               ),
//                               deleteIcon: Icon(Icons.close, size: 14),
//                               onDeleted: () {
//                                 selectedBrands.remove(id);
//                                 selectedBrandName.remove(brand['name'] );
//                               },
//                             ),
//                           );
//                         }).toList(),
//                       ),
//                     );
//                   }),
//
//                   // --- Minimal vertical spacing between brands and models ---
//                   Obx(() {
//                     if (selectedmodals.isEmpty || selectedBrands.isEmpty) return SizedBox.shrink();
//                     return SizedBox(height: 2); // very small gap
//                   }),
//
//                   // --- Models Chips ---
//                   Obx(() {
//                     if (selectedmodals.isEmpty) return SizedBox.shrink();
//                     return SingleChildScrollView(
//                       scrollDirection: Axis.horizontal,
//                       child: Row(
//                         children: selectedmodals.map((id) {
//                           final model = pc.modelData
//                               .firstWhere((b) => b['id'] == id, orElse: () => {});
//                           return Padding(
//                             padding: const EdgeInsets.only(right: 4.0),
//                             child: Chip(
//                               backgroundColor: Colors.white,
//                               visualDensity: VisualDensity.compact,
//                               padding: EdgeInsets.zero,
//                               labelPadding: EdgeInsets.symmetric(horizontal: 4.0, vertical: 2.0),
//                               label: Text(
//                                 model['model_name'] ?? "",
//                                 style: TextStyle(fontSize: 10),
//                               ),
//                               deleteIcon: Icon(Icons.close, size: 14),
//                               onDeleted: () {
//                                 selectedmodals.remove(id);
//                                 selectedModelName.remove(model['model_name']);
//                               },
//                             ),
//                           );
//                         }).toList(),
//                       ),
//                     );
//                   }),
//                 ],
//               )
//
//
//           ),
          Obx(
                () => pc.detailLoading.value == true
                ? Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: GridView.builder(
                    gridDelegate:
                    SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount:
                        2, // number of items in each row
                        mainAxisSpacing: 10.0, // spacing between rows
                        crossAxisSpacing:
                        10.0, // spacing between columns
                        childAspectRatio: 0.65),
                    itemCount: 20,
                    // itemCount: pc.getProductDetailList.length,
                    itemBuilder: (context, index) {
                      return Container(
                        height: 60,
                        width: 60,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade200,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Shimmer.fromColors(
                          baseColor: Colors.grey.shade300,
                          highlightColor: Colors.grey.shade100,
                          child: Column(
                            children: [
                              Expanded(
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  // child: Shimmer.fromColors(
                                  // baseColor: Colors.grey.shade300,
                                  // highlightColor: Colors.grey.shade100,
                                  child: Container(
                                    // height: 70,
                                    // width: 60,
                                    decoration: BoxDecoration(
                                      color: Colors.grey.shade400,
                                      borderRadius:
                                      BorderRadius.circular(10),
                                    ),
                                    // ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                    vertical: 4, horizontal: 8),
                                child: Container(
                                  height: 20,
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                    color: Colors.grey.shade400,
                                    borderRadius:
                                    BorderRadius.circular(7),
                                  ),
                                ),
                              ),
                              Padding(
                                padding:
                                const EdgeInsets.only(bottom: 10),
                                child: Container(
                                  height: 30,
                                  width: 80,
                                  decoration: BoxDecoration(
                                    color: Colors.grey.shade400,
                                    borderRadius:
                                    BorderRadius.circular(10),
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                      );
                    }),
              ),
            )
                : Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListView.builder(
                  // gridDelegate:
                  // SliverGridDelegateWithFixedCrossAxisCount(
                  //     crossAxisCount:
                  //     2, // number of items in each row
                  //     mainAxisSpacing: 10.0, // spacing between rows
                  //     crossAxisSpacing:
                  //     10.0, // spacing between columns
                  //     childAspectRatio: 0.75),
                    itemCount: pc.searchedProductDetailList.length,
                    // itemCount: pc.getProductDetailList.length,
                    itemBuilder: (context, index) {
                      // final product = pc.getProductDetailList[index];
                      final product = pc.searchedProductDetailList[index];
                      print(product.stock_price);
                      if (pc.getProductDetailList.isEmpty) {
                        return Center(
                            child: Column(
                              children: [
                                SizedBox(
                                    width: 50,
                                    height: 50,
                                    child: CircularProgressIndicator(
                                      color: AppColors.mainblue,
                                    )),
                                SizedBox(height: 10),
                                Text("loading..."),
                              ],
                            ));
                      } else {
                        return IntrinsicHeight(
                            child: ProductCard(product: product));
                      }
                    }),
              ),
            ),
          ),
          // Spacer(),
          Obx(() {
            return Visibility(
              visible: pc.calculateamount() > 0.0,
              child: Container(
                padding: EdgeInsets.all(10),
                height: 65,
                decoration: BoxDecoration(
                  color: Colors.white,
                ),
                child: Row(
                  children: [
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        RichText(
                          text: TextSpan(
                            text: "Amount: ",
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.grey.shade600,
                            ),
                            children: [
                              TextSpan(
                                text: "₹ ${formatNumber(pc.calculateamount())}",
                                style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    Spacer(),
                    GestureDetector(
                      onTap: () {
                        pc.setCartProductInitally();

                        // for (var product in pc.getProductDetailList) {
                        //   if (product.selectedQty == null) {
                        //   } else {
                        //     if (product.selectedQty! > 0) {
                        //       var existingProductIndex =
                        //           pc.selectedProducts.indexWhere(
                        //         (selectedProduct) =>
                        //             selectedProduct.id == product.id,
                        //       );

                        //       if (existingProductIndex != -1) {
                        //         var existingProduct =
                        //             pc.selectedProducts[existingProductIndex];
                        //         if (existingProduct.selectedQty !=
                        //             product.selectedQty) {
                        //           // Product already exists and its quantity has changed, update quantity
                        //           existingProduct.selectedQty =
                        //               product.selectedQty!;
                        //         }
                        //       } else {
                        //         pc.selectedProducts.add(product);
                        //         pc.showDes.add(false);
                        //       }
                        //     }
                        //   }
                        // }

                        Navigator.pop(context, pc.selectedProducts);
                      },
                      child: Container(
                        height: double.maxFinite,
                        width: 130,
                        margin: EdgeInsets.symmetric(horizontal: 10),
                        padding:
                        EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: AppColors.mainblue,
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Text(
                              "Continue",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 19,
                              ),
                            ),
                            Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.white,
                              size: 16,
                            )
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          })
        ],
      ),
    );

  }
  void _showCategorySheet()
  {
    final TextEditingController searchCtrl = TextEditingController();
    final RxString searchQuery = "".obs;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) {
        return StatefulBuilder(
          builder: (context, setState) {
            return Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(height: 50,),
                  const Text("Select Categories",
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const Divider(),
                  Container(
                    height: 42,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(24),

                    ),
                    child: TextField(
                      controller: searchCtrl,
                      onChanged: (val) => searchQuery.value = val.toLowerCase(),
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.search),
                        hintText: "Search Categories...",
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Obx(() {
                      final filtered = pc.categoryData.where((b) {
                        final name = (b['name'] ?? '').toString().toLowerCase();
                        return name.contains(searchQuery.value);
                      }).toList();
                      return
                        ListView.builder(
                          itemCount: filtered.length,
                          itemBuilder: (_, index) {
                            final brand = filtered[index];
                            final isSelected = selectedCategories.contains(
                                brand['id']);
                            return CheckboxListTile(
                              title: Text(brand['name'] ?? ''),
                              value: isSelected,
                              onChanged: (val) {
                                setState(() {
                                  if (isSelected) {
                                    selectedCategories.remove(brand['id']);
                                    selectedCategorylName.remove(brand['code']);
                                  } else {
                                    selectedCategories.add(brand['id']);
                                    selectedCategorylName.add(brand['code']);
                                  }
                                });
                              },
                            );
                          },
                        );
                    }),
                  ),
                  ElevatedButton(
                    onPressed: () async {
                      Navigator.pop(context);
                      pc.searchType = selectedCategorylName;
                      await pc.getProductDetailsList();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.mainblue,
                      minimumSize: const Size(double.infinity, 45),
                    ),
                    child: const Text("Apply Filter", style: TextStyle(color: Colors.white)),
                  )
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _showBrandSheet() {
    final TextEditingController searchCtrl = TextEditingController();
    final RxString searchQuery = "".obs;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) {
        return StatefulBuilder(
          builder: (context, setState) {
            return Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(height: 50,),
                  const Text("Select Brands",
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const Divider(),
                  Container(
                    height: 42,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(24),

                    ),
                    child: TextField(
                      controller: searchCtrl,
                      onChanged: (val) => searchQuery.value = val.toLowerCase(),
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.search),
                        hintText: "Search brands...",
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Obx(() {
                      final filtered = pc.brandData.where((b) {
                        final name = (b['name'] ?? '').toString().toLowerCase();
                        return name.contains(searchQuery.value);
                      }).toList();
                      return
                        ListView.builder(
                          itemCount: filtered.length,
                          itemBuilder: (_, index) {
                            final brand = filtered[index];
                            final isSelected = selectedBrands.contains(
                                brand['id']);
                            return CheckboxListTile(
                              title: Text(brand['name'] ?? ''),
                              value: isSelected,
                              onChanged: (val) {
                                setState(() {
                                  if (isSelected) {
                                    selectedBrands.remove(brand['id']);
                                    selectedBrandName.remove(brand['name']);
                                  } else {
                                    selectedBrands.add(brand['id']);
                                    selectedBrandName.add(brand['name']);
                                  }
                                });
                              },
                            );
                          },
                        );
                    }),
                  ),
                  ElevatedButton(
                    onPressed: () async {
                      Navigator.pop(context);
                      pc.searchBrand = selectedBrandName;
                      await pc.getProductDetailsList();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.mainblue,
                      minimumSize: const Size(double.infinity, 45),
                    ),
                    child: const Text("Apply Filter", style: TextStyle(color: Colors.white)),
                  )
                ],
              ),
            );
          },
        );
      },
    );
  }


  void _showModelSheet() {
    final TextEditingController searchCtrl = TextEditingController();
    final RxString searchQuery = "".obs;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) {
        return StatefulBuilder(
          builder: (context, setState) {
            return Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(height: 50,),
                  const Text("Select Models",
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const Divider(),
                  // 🔍 Search bar
                  Container(
                    height: 42,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(24),

                    ),
                    child: TextField(
                      controller: searchCtrl,
                      onChanged: (val) => searchQuery.value = val.toLowerCase(),
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.search),
                        hintText: "Search models...",
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Obx(() {
                      final filtered = pc.modelData.where((m) {
                        final name = (m['model_name'] ?? '').toString().toLowerCase();
                        return name.contains(searchQuery.value);
                      }).toList();
                      return ListView.builder(
                        itemCount: filtered.length,
                        itemBuilder: (_, index) {
                          final model = filtered[index];
                          final isSelected = selectedmodals.contains(model['id']);
                          return CheckboxListTile(
                            title: Text(model['model_name'] ?? ''),
                            value: isSelected,
                            onChanged: (val) {
                              setState(() {
                                if (isSelected) {
                                  selectedmodals.remove(model['id']);
                                  selectedModelName.remove(model['model_name']);
                                } else {
                                  selectedmodals.add(model['id']);
                                  selectedModelName.add(model['model_name']);
                                }
                              });
                            },
                          );
                        },
                      );
                    }),
                  ),
                  ElevatedButton(
                    onPressed: () async {
                      Navigator.pop(context);
                      pc.searchModel = selectedModelName;
                      await pc.getProductDetailsList();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.mainblue,
                      minimumSize: const Size(double.infinity, 45),
                    ),
                    child: const Text("Apply Filter", style: TextStyle(color: Colors.white)),
                  )
                ],
              ),
            );
          },
        );
      },
    );
  }


  Widget _filterButton(String title, VoidCallback onTap) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4.0),
        child: ElevatedButton(
          onPressed: onTap,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.white,
            foregroundColor: Colors.black,
            elevation: 1,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
              side: BorderSide(color: Colors.grey.shade300),
            ),
          ),
          child: Text(title, style: const TextStyle(fontSize: 13)),
        ),
      ),
    );
  }

}
